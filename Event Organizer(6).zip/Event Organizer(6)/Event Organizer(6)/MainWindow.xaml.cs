﻿using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Threading;

namespace EventOrganizer
{
    public partial class MainWindow : Window
    {
        // Коллекция для хранения событий
        public ObservableCollection<Event> Events { get; set; }

        // Таймер для проверки времени событий
        private DispatcherTimer eventTimer;

        public MainWindow()
        {
            InitializeComponent();

            // Инициализация коллекции событий
            Events = new ObservableCollection<Event>();
            EventListView.ItemsSource = Events;

            // Установка текст-заполнителя и регистрация событий для TextBox
            EventNameTextBox.Text = "Введите событие";
            EventNameTextBox.Foreground = Brushes.Gray;
            EventNameTextBox.GotFocus += TextBox_GotFocus;
            EventNameTextBox.LostFocus += TextBox_LostFocus;

            // Инициализация таймера для проверки событий каждую минуту
            eventTimer = new DispatcherTimer();
            eventTimer.Interval = TimeSpan.FromMinutes(1);
            eventTimer.Tick += EventTimer_Tick;
            eventTimer.Start();
        }

        // Обработчик для TextBox при получении фокуса (убирает текст-заполнитель)
        private void TextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            if (EventNameTextBox.Text == "Введите событие")
            {
                EventNameTextBox.Text = "";
                EventNameTextBox.Foreground = Brushes.Black;
            }
        }

        // Обработчик для TextBox при потере фокуса (добавляет текст-заполнитель, если поле пустое)
        private void TextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(EventNameTextBox.Text))
            {
                EventNameTextBox.Text = "Введите событие";
                EventNameTextBox.Foreground = Brushes.Gray;
            }
        }

        // Добавление события в список
        private void AddEventButton_Click(object sender, RoutedEventArgs e)
        {
            if (EventNameTextBox.Text == "Введите событие" || string.IsNullOrWhiteSpace(EventNameTextBox.Text))
            {
                MessageBox.Show("Введите название события.");
                return;
            }

            var selectedDate = EventCalendar.SelectedDate;
            if (selectedDate == null)
            {
                MessageBox.Show("Выберите дату для события.");
                return;
            }

            var newEvent = new Event
            {
                Name = EventNameTextBox.Text,
                Date = selectedDate.Value
            };

            Events.Add(newEvent);
            EventNameTextBox.Clear();
            EventNameTextBox.Text = "Введите событие";
            EventNameTextBox.Foreground = Brushes.Gray;
        }

        // Проверка времени событий для уведомления
        private void EventTimer_Tick(object sender, EventArgs e)
        {
            var now = DateTime.Now;
            foreach (var ev in Events.Where(ev => ev.Date > now && ev.Date <= now.AddMinutes(10)))
            {
                MessageBox.Show($"Напоминание: Событие '{ev.Name}' начнется через 10 минут!", "Напоминание", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }
    }

    // Класс для события
    public class Event
    {
        public string Name { get; set; }
        public DateTime Date { get; set; }
    }
}
