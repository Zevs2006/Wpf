﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace A_program_for_route_planning_5_
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
