﻿using Microsoft.Maps.MapControl.WPF;
using System.Collections.Generic;
using System.Windows;

namespace RoutePlanner
{
    public partial class MainWindow : Window
    {
        private List<Location> waypoints = new List<Location>();

        public MainWindow()
        {
            InitializeComponent();
        }

        private void AddPoint_Click(object sender, RoutedEventArgs e)
        {
            var random = new Random();
            double latitude = 47.6097 + random.NextDouble() * 0.1; 
            double longitude = -122.3331 + random.NextDouble() * 0.1; 
            var location = new Location(latitude, longitude);
            waypoints.Add(location);
            MyMap.Children.Add(new Pushpin { Location = location });
        }

        private void CalculateRoute_Click(object sender, RoutedEventArgs e)
        {
            if (waypoints.Count < 2)
            {
                MessageBox.Show("Добавьте хотя бы две точки для построения маршрута.");
                return;
            }


            RouteInfo.Text = $"Маршрут с {waypoints.Count} точками.";
        }
    }
}
