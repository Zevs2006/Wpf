﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace Task_Manager_using_MVVM_1_
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
