﻿using System;
using System.Collections.ObjectModel;
using System.Data.SQLite;
using System.Windows;

namespace TaskManager
{
    public partial class MainWindow : Window
    {
        private const string ConnectionString = "Data Source=tasks.db;Version=3;";
        private ObservableCollection<TaskModel> Tasks { get; set; }
        private TaskModel SelectedTask { get; set; }

        public MainWindow()
        {
            InitializeComponent();
            Tasks = new ObservableCollection<TaskModel>();
            TaskListView.ItemsSource = Tasks;
            LoadTasks();
        }

        private void LoadTasks()
        {
            using (var connection = new SQLiteConnection(ConnectionString))
            {
                connection.Open();
                var command = new SQLiteCommand("CREATE TABLE IF NOT EXISTS Tasks (Id INTEGER PRIMARY KEY AUTOINCREMENT, Title TEXT, Description TEXT, IsCompleted INTEGER)", connection);
                command.ExecuteNonQuery();

                command = new SQLiteCommand("SELECT * FROM Tasks", connection);
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Tasks.Add(new TaskModel
                        {
                            Id = reader.GetInt32(0),
                            Title = reader.GetString(1),
                            Description = reader.GetString(2),
                            IsCompleted = reader.GetInt32(3) == 1
                        });
                    }
                }
            }
        }

        private void AddTask_Click(object sender, RoutedEventArgs e)
        {
            var title = TitleTextBox.Text;
            var description = DescriptionTextBox.Text;

            if (string.IsNullOrWhiteSpace(title))
            {
                MessageBox.Show("Введите название задачи.");
                return;
            }

            var newTask = new TaskModel { Title = title, Description = description, IsCompleted = false };
            AddTaskToDatabase(newTask);
            Tasks.Add(newTask);
            ClearInputFields();
        }

        private void EditTask_Click(object sender, RoutedEventArgs e)
        {
            if (SelectedTask != null)
            {
                SelectedTask.Title = TitleTextBox.Text;
                SelectedTask.Description = DescriptionTextBox.Text;
                UpdateTaskInDatabase(SelectedTask);
                TaskListView.Items.Refresh();
                ClearInputFields();
            }
        }

        private void DeleteTask_Click(object sender, RoutedEventArgs e)
        {
            if (SelectedTask != null)
            {
                DeleteTaskFromDatabase(SelectedTask.Id);
                Tasks.Remove(SelectedTask);
                ClearInputFields();
            }
        }

        private void TaskListView_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            SelectedTask = (TaskModel)TaskListView.SelectedItem;
            if (SelectedTask != null)
            {
                TitleTextBox.Text = SelectedTask.Title;
                DescriptionTextBox.Text = SelectedTask.Description;
            }
        }

        private void ClearInputFields()
        {
            TitleTextBox.Clear();
            DescriptionTextBox.Clear();
            SelectedTask = null;
            TaskListView.SelectedItem = null;
        }

        private void AddTaskToDatabase(TaskModel task)
        {
            using (var connection = new SQLiteConnection(ConnectionString))
            {
                connection.Open();
                var command = new SQLiteCommand("INSERT INTO Tasks (Title, Description, IsCompleted) VALUES (@Title, @Description, @IsCompleted)", connection);
                command.Parameters.AddWithValue("@Title", task.Title);
                command.Parameters.AddWithValue("@Description", task.Description);
                command.Parameters.AddWithValue("@IsCompleted", task.IsCompleted ? 1 : 0);
                command.ExecuteNonQuery();
            }
        }

        private void UpdateTaskInDatabase(TaskModel task)
        {
            using (var connection = new SQLiteConnection(ConnectionString))
            {
                connection.Open();
                var command = new SQLiteCommand("UPDATE Tasks SET Title = @Title, Description = @Description, IsCompleted = @IsCompleted WHERE Id = @Id", connection);
                command.Parameters.AddWithValue("@Id", task.Id);
                command.Parameters.AddWithValue("@Title", task.Title);
                command.Parameters.AddWithValue("@Description", task.Description);
                command.Parameters.AddWithValue("@IsCompleted", task.IsCompleted ? 1 : 0);
                command.ExecuteNonQuery();
            }
        }

        private void DeleteTaskFromDatabase(int taskId)
        {
            using (var connection = new SQLiteConnection(ConnectionString))
            {
                connection.Open();
                var command = new SQLiteCommand("DELETE FROM Tasks WHERE Id = @Id", connection);
                command.Parameters.AddWithValue("@Id", taskId);
                command.ExecuteNonQuery();
            }
        }
    }

    public class TaskModel
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public bool IsCompleted { get; set; }
    }
}
